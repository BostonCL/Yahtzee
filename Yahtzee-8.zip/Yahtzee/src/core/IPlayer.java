package core;

import java.util.ArrayList;


public interface IPlayer 
{
    public void rollDice(Roll roll);
    public void selectCategory(Roll keep);
}
