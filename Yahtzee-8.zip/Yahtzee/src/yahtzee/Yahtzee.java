// Boston Learned
// Assingment 2
// COP 3330
// Karin Whiting


package yahtzee;


import javax.swing.JOptionPane;
import userInterface.YahtzeeUi;

public class Yahtzee 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    { 
        YahtzeeUi yahtzeeUi = new YahtzeeUi();
    }   
}
